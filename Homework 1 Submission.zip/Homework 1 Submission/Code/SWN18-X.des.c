#include <openssl/des.h>
#include <string.h>
#define ENC 1
#define DEC 0

int main(int  argc,  char*  argv[])
{
    unsigned long _key = (unsigned long)strtoul(argv[1] , 0, 16);
    unsigned long _iv = (unsigned long)strtoul(argv[2] , 0, 16);
    char* filename = argv[3];
    char* output_filename = argv[4];

    des(_key, _iv, filename, output_filename);

    return 0;
}
void des(unsigned long _key, unsigned long _iv, char* filename, char* output_filename){
    struct  timeval start;
    struct  timeval end;
    unsigned  long diff;

    long	in[2];
    static unsigned long cbc_key;
	// key
    cbc_key = _key; 
    // iv
    in[1]  = _iv;
    // flaw there, still no idea how to define buff, could result in memeory leak.
    char buff[3000000];
   
    FILE *fp = NULL;
    fp = fopen(filename, "r");
    fscanf(fp, "%s", buff);

    int rep = (int)(strlen(buff)/8);
    if (strlen(buff)%8 > 0){
        rep += 1;
    }
    int rep1 = rep;
    int count = 0;
    des_key_schedule key;
    if (des_set_key_checked(&cbc_key,key) != 0)
    {
    printf("\nkey error\n");
    }
    long enc[rep];
    long dec[rep];
    gettimeofday(&start,NULL);
    // cbc encryption
    while(rep1>0){
        unsigned char temp_str[8];
        unsigned int* temp_str2;
	    for (int i = 0; i < 8; i++){
            temp_str[i] = buff[count*8 + i];
        }
        in[0] = temp_str;

        if (count==0){
        in[0] ^= in[1];}
        else{
            in[0] ^= enc[count-1];
        }

        des_encrypt1(in,key,ENC);
        enc[count] = in[0];
        count += 1;
        rep1--;
        }
    // starts counting
    gettimeofday(&end,NULL);

    diff = 1000000 * (end.tv_sec-start.tv_sec)+ end.tv_usec-start.tv_usec;
    printf("the encrypt time difference is %ld microsecond \n",diff);
    fp = fopen(output_filename,"a");

    for (int i = 0; i < rep; i++){
         fprintf(fp,"%c",enc[i]);
         //printf("%c\n",enc[i]);
         }

    int _start = 0;
    //printf("decrypted message is not shown there:");
    gettimeofday(&start,NULL);
    while(_start < rep){
        in[0] = enc[_start];
        des_encrypt1(in,key,DEC);
        
	if (_start==0)
        {
        in[0] ^= in[1];
        }
        else
        {
            in[0] ^= enc[_start-1];
        }

        dec[_start] = in[0];
        // if decrypted message needed, remove // of next line.
        //printf("%s",dec[_start]);
        _start++;
        }
    printf("\n");
    //end time
    gettimeofday(&end,NULL);
    // microseconds
    diff = 1000000 * (end.tv_sec-start.tv_sec)+ end.tv_usec-start.tv_usec;
    printf("the decrypt time difference is %ld microsecond\n",diff);
}

